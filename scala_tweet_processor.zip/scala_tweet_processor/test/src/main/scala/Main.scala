import scala.io.Source
import java.util.zip.GZIPInputStream
import java.io._
import java.util.regex.Pattern
import scala.collection.mutable.ListBuffer
import java.io.{FileWriter, PrintWriter}
import scala.io.Codec
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import scala.collection.mutable.HashMap
import util.control.Breaks._
import edu.arizona.sista.struct._
import scala.collection.immutable.ListMap


class GeoTagger(val statePatterns: Map[String, List[Pattern]]) {

  	def this(stateFilename: String) =
    this(GeoTag.loadStatePatterns(stateFilename))

  	def this(source: Source = Source.fromFile("src/main/scala/states.txt")) =
    this(GeoTag.loadStatePatterns(source))

  	def normalizeLocation(loc:String, timeZone:String):Option[String] = GeoTag.normalizeLocation(loc, timeZone,
    statePatterns)

}

object GeoTag {

  var tfs = new collection.mutable.HashMap[String, Counter[String]]
  var vocabAllWords = new Counter[String]

  def main(args:Array[String]) : Unit = {
    val stateFile = "src/main/scala/states.txt"
   // val in_file = "C:/Users/Musa/Documents/input100.txt"
    // val in_file = "/data1/home/hangchen/all.txt"
    val in_file = "/data1/home/ahmadmusa/segmentaa"
    val out_file = "out.txt"
    
    val states = loadStatePatterns(stateFile)
    // println(states)

    //println("Hello");
    //println(normalizeLocation("houston, tx", "Pacific Time (US & Canada)", states))
    //println(normalizeLocation("new york, ny", "Pacific Time (US & Canada)", states))

    val os = new PrintWriter(new FileWriter(out_file))
    geoTagTweets(states, in_file, os)
    //for( (key,value) <- tfs) println(key + " " + value + "\n")

   
    val writer = new PrintWriter(new File("vocabAllWords.txt"))
       
    println(vocabAllWords.size)
    var vocab = vocabAllWords.toString()
    writer.write(vocab)
    // for ( x <- vocabAllWords)
    // {
    //   writer.write(x + "\t")
    // }
    writer.close()
// println(tfs)

    var docCount = new Counter[String]()
    for (doc <- tfs.values)
      for (term <- doc.keySet)
        docCount.incrementCount(term)

    //println("docCount : "  + docCount);
    val N = tfs.size // should be 50 or 51 or 52, idk

    val idfs: Counter[String] = docCount.mapValues(count => Math.log(N / count))
    //println("idf : "  + idfs);
    // println("TF -----------------------------------------------")
    // for( state <- tfs.keySet)
    // {
    //   println("[ " + state + "] : ")
    //   if( tfs(state).size > 0)
    //   {
    //     val data = tfs(state).sorted
    //     println(data(0) + " " + data(data.size-1))
    //   }
    // }

    //var tfsSorted = ListMap(tfs.toSeq.sortWith(_._1 < _._1):_*)
    
    
    // for ( x <- vocabFoodWords)
    // {
    //   print(x + "\t")
    // }
    // println("\n")
    
    //println(tfsSorted)
    // tfs.sorted
    for( state <- tfs.keySet)
    {
      //println("[ " + state + "] : ")
      val res : Counter[String]= tfs(state)
      for ( key <- res.keySet)
      {
        val v = res.getCount(key) * idfs.getCount(key) 
        res.setCount(key, v)
      }
      tfs(state) = res
    }
    
    // println(" -------------------  TFIDF  ----------------------------")
    //  for( state <- tfs.keySet)
    // {
    //   println("[ " + state + "] : ")
    //   if( tfs(state).size > 0)
    //   {
    //     val data = tfs(state).sorted
    //     println(data(0) + " " + data(data.size-1))
    //   }
    // }

    // val totalCounts = tfs.values.reduce(_ + _)
    // println("total Counts " + totalCounts)
    // val n = totalCounts.values.sum
    // var output = new Counter[String]
    // tfs.mapValues(tf => {
    //   val totalPos = tf.values.sum
    //   val newC = new Counter[String]
    //   for ((word, a) <- tf.toSeq) {
    //     val b = totalCounts.getCount(word)
    //     val c = totalPos - a
    //     val pmi = math.log((a * n) / ((a + c) * (a + b)))
    //     newC.setCount(word, pmi * math.log(a))
    //   }
    //   newC
    // })

    // println(tfs)

   

    os.close()
  }

  def geoTagTweets(states:Map[String, List[Pattern]], file:String, os:PrintWriter) {
    //Create an Map to hash the array with first element is for all tweets with locations mentioned the key.
    //Second element is the number of location-tagged tweets mentiong the key.
    //0-breakfast, 1-brunch, 
    var table1_infoArray = Array(Array(0, 0), Array(0, 0), Array(0, 0), Array(0, 0), Array(0, 0), Array(0, 0), Array(0, 0))
    val tag_indexHash = HashMap(("#breakfast", 0), ("brunch", 1), ("#dinner", 2), ("#lunch", 3), ("#meal", 4), ("#snack", 5), ("#supper", 6))

    var lineCount = 0
    var tweetsWithLoc = 0
    var totalTweets = 0
    var tweetsNormed = 0
    //val locStats = new Counter[String]()
    //val stateStats = new Counter[String]()
    //val unnormLocs = new Counter[String]()
    var metaLine:String = null
    var isNormalized = false
    
    //println("break1");
    // var inputSrc = Source.fromFile(file, "Unicode")
    var inputSrc = Source.fromFile(file, "UTF-8")
	//var inputTwt = Source.fromFile("tweetsWithStates.txt", "UTF-8")
    var inputTwt = new FileWriter("tweetsWithStates0.txt", true)
    var inputTwtCity = new FileWriter("tweetsWithCities.txt", true)

	var fullTweetData = ""
    var tweetText = ""
    for (line <- inputSrc.getLines) {
   		//println(line);
   		
      lineCount += 1
      
      if ( lineCount  % 10000 == 0)
      {
        println("reached a 10000 ")
      }
      breakable{ 
        var nums = 48277384
        if(lineCount >= nums && lineCount < nums+10) {break}
      
      if( fullTweetData == "")
      {
        fullTweetData = fullTweetData + line
      }
      else 
      {
        fullTweetData = fullTweetData + "\n" + line
      }
      if(lineCount % 3 == 1) {
        metaLine = line

        // println("meta line  -> "  + metaLine)
      } else if(lineCount % 3 == 0) {
        tweetText = line
        totalTweets += 1
        val bits = metaLine.split('\t')
        // println("bits -> " + bits)
        var loc = "nil"
        // loc = bits(3).toLowerCase
         try {
           loc = bits(3).toLowerCase
         } catch {
           case e: ArrayIndexOutOfBoundsException =>
           // print("the length is: "+bits.length) 
           println("the dataset get error at line "+lineCount)
           println ("###############################################################")
           println ("   Term   |   #of Tweets      |  # with normalized US location|")
           for (key <- tag_indexHash.keySet) {
             var counterArray = table1_infoArray(tag_indexHash.get(key).get)
             var total = counterArray(0)
             var normalized = counterArray(1)
             println (key + "           " + total + "                           " + normalized + "")
           }
           println("Total tweets:     " + totalTweets + "                       " + tweetsNormed)

            for( i <- bits) {print(i+" ")}
            println()
            return()

         }
	      	
	        // println("loc " + loc);
	        //var newLoc = loc.replaceAll("\\s+", "")
       		//println(newLoc)
          var timeZone = "nil"
          if(bits.length >= 6) {
	           timeZone = bits(6).toLowerCase
	    	  }
	       // locStats.incrementCount(loc)
	        if(loc != "nil") {
	         //println("loc not equal nil")
	          tweetsWithLoc += 1
	          normalizeLocation(loc, timeZone, states) match {
	            case Some(state) => {
	              tweetsNormed += 1
                isNormalized = true
                if (!tfs.contains(state)) tfs += ((state, new Counter[String]()))
                val sc = tfs(state)
                // println("\n Done : " + tweetText);
                tweetText = tweetText.trim.replaceAll(" +", " ");
                val tokenList: List[String] = tweetText.split(" ").map(_.trim).toList
                //println("Success")
                for (rawToken <- tokenList) {
                  // get rid of hashtags
                //println(" Raw : " + rawToken)
                  val stripToken = if (rawToken.charAt(0) == '#') rawToken.substring(1) else rawToken
                  if (okTerm(stripToken)) {
                      //vocabFoodWords +:= stripToken
                      sc.incrementCount(stripToken)
                  }
                  vocabAllWords.incrementCount(stripToken)

                }
                //println("Success getting raw")
               /*val writer = new FileWriter(state + ".txt", true)
               writer.write(tweetText + "\n")
               writer.close()
               */
	             // stateStats.incrementCount(state)
	              // os.println(state + "\t" + line.replaceAll("\\s+", " "))
	        inputTwt.write(state + "\t" + tweetText + "\n")    
		}
	            case None => {
                isNormalized = false
	            	//unnormLocs.incrementCount(loc)
	            	//println("not match for location")
	            }
	        }
	        //println("Total tweets: " + totalTweets)
	       	//println("Tweets with location info: " + tweetsWithLoc)
    		  //println("Tweets that could be normalized: " + tweetsNormed)
	        }
    	    for (key <- tag_indexHash.keySet) {
             if (line.contains(key)) {
               table1_infoArray(tag_indexHash.get(key).get)(0) += 1
               if (isNormalized) {
                  table1_infoArray(tag_indexHash.get(key).get)(1) += 1
               }
             }
          }
          tweetText = ""
          fullTweetData = ""
        }
     } 
    }

    /*val showLocs = false
    if(showLocs) {
      for(t <- locStats.sorted) {
        if(t._2 > 1) {
          println(t._1 + "\t" + t._2)
        }
      }
    }

    val showStates = false
    if(showStates) {
      for(t <- stateStats.sorted) {
        println(t._1 + "\t" + t._2)
      }
    }

    val showUnnorm = false
    if(showUnnorm) {
      for(t <- unnormLocs.sorted) {
        if(t._2 > 10) {
          println(t._1 + "\t" + t._2)
        }
      }
    }
	*/
    
    //println("Total tweets: " + totalTweets)
    //println("Tweets with location info: " + tweetsWithLoc)
    //println("Tweets that could be normalized: " + tweetsNormed)
    println ("###############################################################")
    println ("   Term   |   #of Tweets      |  # with normalized US location|")
    for (key <- tag_indexHash.keySet) {
      var counterArray = table1_infoArray(tag_indexHash.get(key).get)
      var total = counterArray(0)
      var normalized = counterArray(1)
      println (key + "           " + total + "                           " + normalized + "")
    }
    println("Total tweets:     " + totalTweets + "                       " + tweetsNormed)
    inputTwt.close()
    // tfs.toMap
  }

  def okTerm(term: String) = {
     FoodWords.words.contains(term)
    //else !term.startsWith("@") && !term.startsWith("http")
  }

/*
	def loadFile(filename: String): BufferedSource = {
	    if(filename.endsWith(".gz"))
	      io.Source.fromInputStream(new GZIPInputStream(new BufferedInputStream(new FileInputStream(filename))))
	    else
	      io.Source.fromFile(filename)
	}
  */

  val USA_SUFFIX = Pattern.compile("([\\s*,]?\\s*USA?\\s*$)|([\\s*,]?\\s*united\\s*states\\s*(of\\s*america)?\\s*$)", Pattern.CASE_INSENSITIVE)

  def normalizeLocation(loc:String, timeZone:String, states:Map[String, List[Pattern]]):Option[String] = {
    // remove any potential USA suffixes
    val m = USA_SUFFIX.matcher(loc)
    var l = loc
    //println("Location received : " + l);
    if(m.matches()) {
      l = loc.substring(0, m.start())
      // println(s"STRIPPED USA: [$loc] to [$l]")
    }

    if(l == "") {
    	//println("No location found");
    	return None
	}
    // special case: la
    if(loc == "la") {
      if(timeZone == null) {
        // can't normalize this one
        return None
      } else if(timeZone.contains("pacific")) {
        //println("LA NORMALIZED TO CA")
        return Some("CA")
      } else if(timeZone.contains("central")) {
        //println("LA NORMALIZED TO LA")
        return Some("LA")
      } else {
        return None
      }
    }

    // return the first state that matches the location
    for(st <- states.keys) {
      for(p <- states(st)) {
        if(p.matcher(l).find()) {
          // println(s"[$l] normalized to [$st]")
          return Some(st)
        }
      }
    }
    None
  }

  def loadStatePatterns(source: Source) = {
    val states = new collection.mutable.HashMap[String, List[Pattern]]
    var count = 0
    for (line <- source.getLines) {
      count += 1
      val bits = line.split('\t')
      val st = bits(0).trim
      val pb = new ListBuffer[Pattern]
      for(i <- 1 until bits.length) {
        val core = bits(i).trim
        pb += Pattern.compile("\\s+" + core + "\\s*$", Pattern. CASE_INSENSITIVE)
        pb += Pattern.compile("^" + core + "\\s*" + "((,\\s*)?" + st + ")?" + "$", Pattern.CASE_INSENSITIVE)
      }
      states += st -> pb.toList
      // println("PATTERNS FOR " + st + ": " + pb.toList)
    }
    // println(s"Loaded $count states.")
    states.toMap
  }

  def loadStatePatterns(file:String): Map[String, List[Pattern]] = {
    loadStatePatterns(Source.fromFile(file))
  }
}
